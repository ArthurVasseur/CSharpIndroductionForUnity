using CSharpEngine.Components;
using CSharpEngine.Physics;

namespace CSharpEngine.Scripts;

public class Player : Component
{
    public static Player Instance { get; private set; }
    public int Health = 3;
    private readonly int _speed = 300;

    public override void OnConstruct()
    {
        base.OnConstruct();
        Input.RegisterAction("Up", KeyCode.Z);
        Input.RegisterAction("Down", KeyCode.S);
        Input.RegisterAction("Left", KeyCode.Q);
        Input.RegisterAction("Right", KeyCode.D);
        Input.RegisterAction("Fire", KeyCode.Space);
        Instance = this;
    }

    public override void Update(float deltaTime)
    {
        if (Input.GetKeyDown("Up"))
        {
            Transform.Position.Y -= _speed * deltaTime;
        }
        if (Input.GetKeyDown("Down"))
        {
            Transform.Position.Y += _speed * deltaTime;
        }
        if (Input.GetKeyDown("Right"))
        {
            Transform.Position.X += _speed * deltaTime;
        }
        if (Input.GetKeyDown("Left"))
        {
            Transform.Position.X -= _speed * deltaTime;
        }
        if (Input.GetKeyDown("Fire"))
        {
            GameObject gameObject = new GameObject();
            gameObject.AddComponent(new Transform(new Vector2D(Transform.Position.X, Transform.Position.Y + 20), Transform.Rotation, new Vector2D(Transform.Scale.X, Transform.Scale.Y)));
            gameObject.AddComponent(new Sprite("../../../Assets/shot.png"));
            gameObject.AddComponent(new Collider(new Vector2D(5,5), true));
            gameObject.AddComponent(new Shoot());
            Instantiate(gameObject);
        }
    }
}