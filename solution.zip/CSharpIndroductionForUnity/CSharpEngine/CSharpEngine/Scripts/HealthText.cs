using CSharpEngine.Components;

namespace CSharpEngine.Scripts;

public class HealthText : Component
{
    public override void Update(float deltaTime)
    {
        GameObject.GetComponent<Text>()!.Txt = Player.Instance.Health + " HP";
    }
}