using CSharpEngine.Components;
using CSharpEngine.Physics;

namespace CSharpEngine.Scripts;

public class Shoot : Component
{
    public override void OnConstruct()
    {
        base.OnConstruct();
        GameObject.AddComponent(new Collider(new Vector2D(5, 5)));
    }

    public override void Update(float deltaTime)
    {
        Transform.Position.X += 3 * deltaTime;
    }

    public override void OnCollisionEnter(GameObject go)
    {
        var enemy = go.GetComponent<Enemy>();
        if (enemy != null)
        {
            enemy.TakeDamage();
        }
        Destroy(GameObject);
    }

    public override void OneBecameInvisible()
    {
        Destroy(GameObject);
        
        Console.WriteLine("Destroy");
    }
}