using CSharpEngine.Components;

namespace CSharpEngine.Scripts;

public class Enemy : Component
{
    private int _health = 3;
    public override void Update(float deltaTime)
    {
        Transform.Position.X -= 0.2f * deltaTime;
    }
    
    public override void OneBecameInvisible()
    {
        Destroy(GameObject);
    }

    public void TakeDamage()
    {
        _health--;
        if (_health == 0)
        {
            Destroy(GameObject);
        }
    }
}